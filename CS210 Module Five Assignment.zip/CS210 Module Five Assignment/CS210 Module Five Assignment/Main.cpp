/*
* 
* CS210 Module Five - Assignment
* Julrey Solis
* 11/29/2025
* 
*/

//Copied the template from zybook participation activity.

#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
using namespace std;

int main() 
{
	ifstream inFS;
	vector<string> cityList(0);
	vector<int> tempList(0);
	string currentCity;
	int currentTemp;


	
	cout << "Welcome to CS210 Module Five - Assignment" << endl;
	cout << "Created by Julrey Solis" << endl << endl;

	//Opening filename as stated in the guidelines and rubric page. "FahrenheitTemperature.txt"
	cout << "Opening file FahrenheitTemperature.txt." << endl << endl;
	inFS.open("FahrenheitTemperature.txt");
	if (!inFS.is_open())
	{
		cout << "Could not open FahrenheitTemperature.txt." << endl;
		cout << "Goodbye!" << endl;
		return 0;
	}

	/*
	* This iteration goes through the list in the txt file 
	* and add the values to the cityList and tempList to store the information.
	*/
	cout << "Reading data..." << endl << endl;
	inFS >> currentCity;
	inFS >> currentTemp;

	while (!inFS.fail())
	{
		cityList.push_back(currentCity);
		tempList.push_back(currentTemp);
		cout << currentCity << " " << currentTemp << endl;
		inFS >> currentCity;
		inFS >> currentTemp;
	}
	cout << endl;
	if (!inFS.eof())
	{
		cout << "Input failure before reaching end of file." << endl;
	}


	
	//Closing input file
	cout << "Closing file FahrenheitTemperature.txt." << endl << endl;
	inFS.close();

	//Creating new file CelsiusTemperature.txt
	cout << "Creating new file CelsiusTemperature.txt" << endl;
	ofstream outFS;
	outFS.open("CelsiusTemperature.txt");

	if (!outFS.is_open()) {
		cout << "Could not open file CelsiusTemperature.txt" << endl;
	}


	/*
	* For loop to iterate through the list of the cities using the vector string cityList.
	* Then the loop will go through each of the cities 
	* and convert the fahrenheit temp to celcius and output to the CelsiusTemperature.txt file
	*/
	for (int i = 0; i < cityList.size(); i++)
	{
		double celciusTemp;
		celciusTemp = (tempList.at(i) - 32) * (5.0 / 9.0);				// I had to use double variable for Celcius due to the 5/9 fraction.
		outFS << cityList.at(i) << " " << fixed << setprecision(0) << celciusTemp << endl; //I also had to use iomanip to round off the temperature.
		cout << cityList.at(i) << " " << fixed << setprecision(0) << celciusTemp << endl;
	}

	//Closing output file
	outFS.close();
	cout << "Successfully converted the temperature for all cities!" << endl;
	cout << "Goodbye!" << endl;

	return 0;
}